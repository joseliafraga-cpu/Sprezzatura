# Sprezzatura App — Deploy

Arraste a pasta para netlify.com/drop
